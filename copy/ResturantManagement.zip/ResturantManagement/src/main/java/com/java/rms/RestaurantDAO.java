package com.java.rms;

import java.util.List;

public interface RestaurantDAO {
//	String showRestaurantsDao();

}
