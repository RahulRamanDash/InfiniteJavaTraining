package com.java.ejb;


public class Dummy {

	public static void main(String[] args) {
		
	}
}
