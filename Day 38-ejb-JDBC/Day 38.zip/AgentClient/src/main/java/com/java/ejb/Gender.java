package com.java.ejb;

public enum Gender {
	MALE,FEMALE

}
