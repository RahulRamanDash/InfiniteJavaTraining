package com.java.day3;

public class Demo {
	
	public static void main(String[] args) {
		
	}
}
