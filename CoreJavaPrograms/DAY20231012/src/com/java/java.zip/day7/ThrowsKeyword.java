package com.java.day7;

import java.io.IOException;

class M {
	void method() throws IOException {
		throw new IOException("device error");
	}
}

public class ThrowsKeyword {
	public static void main(String args[]) throws IOException {// declare exception
		M m = new M();
		m.method();

		System.out.println("normal flow...");
	}
}
