package com.java.day1;

public class Prog5 {
	static void myMethod(String name) {
		System.out.println("Name is "+name);
	}

	public static void main(String[] args) {
		myMethod("Rahul");
		myMethod("Saurav");
		myMethod("Ansal");
	}
}
