package com.java.day5;

public class Prog1 {

}
