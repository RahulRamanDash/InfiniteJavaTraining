package com.java.day6;

// Base class representing a person
class Person {
    String name;
    int age;

    // Constructor for initializing name and age
    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

// Subclass Student inheriting from Person
class Student extends Person {
    int rollNumber;

    // Constructor for initializing name, age, and roll number
    Student(String name, int age, int rollNumber) {
        // Call the superclass constructor
        super(name, age);
        this.rollNumber = rollNumber;
    }

    // Method to display student information
    void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age + ", Roll Number: " + rollNumber);
    }
}

public class Prog1 {
    public static void main(String[] args) {
        // Create an array of Student objects
        Student[] students = {
            new Student("Alice", 18, 101),
            new Student("Bob", 19, 102),
            new Student("Charlie", 20, 103)
        };

        // Loop through the array and display student information
        for (Student student : students) {
            student.displayInfo();
        }
    }
}
