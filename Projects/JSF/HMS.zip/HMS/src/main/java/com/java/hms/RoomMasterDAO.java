package com.java.hms;


public interface RoomMasterDAO {
	String showRooms();
}
