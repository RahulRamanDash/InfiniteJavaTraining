package com.java.hms;

public interface DoctorMasterDAO {
	String showDoctorDao();
}
