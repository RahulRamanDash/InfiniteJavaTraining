package com.java.hms;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class PatientMasterDaoImpl implements PatientMasterDAO{

	SessionFactory sf;
	Session session;
	
	@Override
	public String addPatient(PatientMaster patient) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.save(patient);
		trans.commit();
		return "addSuccess.jsp?faces-redirect=true";
	}
	

}
