package com.java.hms;

public interface PatientMasterDAO {
	String addPatient(PatientMaster patient);
}
