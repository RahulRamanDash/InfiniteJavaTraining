package com.java.rms;

public enum WalletSource {
	PAYTM, CREDIT_CARD, DEBIT_CARD
}
