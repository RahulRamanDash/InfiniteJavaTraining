package com.java.rms;

public interface VenderDAO {
	String vendorLogin(Vendor vendor);
	
}
