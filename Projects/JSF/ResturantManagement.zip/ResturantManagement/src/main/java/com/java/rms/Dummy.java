package com.java.rms;


public class Dummy {

	public static void main(String[] args) {
		//System.out.println(new CustomerDaoImpl().showCustomerWalleNames());
		System.out.println(new CustomerDaoImpl().purseValue("DEBIT_CARD"));
	}
}
