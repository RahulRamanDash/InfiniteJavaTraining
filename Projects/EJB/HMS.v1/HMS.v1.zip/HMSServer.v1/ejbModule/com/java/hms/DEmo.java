package com.java.hms;

public class DEmo {
	public static void main(String[] args) {
		PatientBeanRemote obj = new PatientBean();
		System.out.println(obj.showPatient());
	}
}
