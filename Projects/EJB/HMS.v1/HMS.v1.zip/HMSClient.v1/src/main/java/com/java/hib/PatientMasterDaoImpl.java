package com.java.hib;

import java.sql.SQLException;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class PatientMasterDaoImpl implements PatientMasterDAO{


	SessionFactory sf;
	Session session;
	
	public String generateOtp() {
		int len=6;
		  String AlphaNumericString = "0123456789";
			  StringBuilder sb = new StringBuilder(len);
			  for (int i=0;i<len;i++) {
			   int index = (int)(AlphaNumericString.length()
			      * Math.random());
			   sb.append(AlphaNumericString
			      .charAt(index));
			  }
			  return sb.toString();
	}
	
	public String validateOtp(PatientMaster patient) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria criteria = session.createCriteria(PatientMaster.class);
		criteria.add(Restrictions.eqOrIsNull("username", patient.getUsername()));
		//criteria.add(Restrictions.eqOrIsNull("passCode", patient.getOtpString()));
		Projection projection = Projections.property("otpString");
		criteria.setProjection(projection);
		String otp = (String) criteria.uniqueResult();
		if(otp.equals(patient.getOtpString())) {
			return "createPassword.jsp?faces-redirect=true";
		}
		else {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			sessionMap.put("otpError","Invalid UserName or Otp...");
			return "Invalid UserName or Otp...";
		}
	}
	public String setPassword(String password, String rePassword) {
		Map<String, Object> sessionMap =
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if(password.equals(rePassword)) {
		
		String user = (String) sessionMap.get("forgotUser");
		PatientMaster patient = searchPatientByUsername(user);
		//patient.setPassword(encPass);
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(patient);
		transaction.commit();		
		return "ValidateOtp.jsp?faces-redirect=true";
		}else {
			sessionMap.put("passError", "Password's not Matching...");
			return "";
		}
		
	}
	
	@Override
	public String addPatientDao(PatientMaster patient) throws ClassNotFoundException, SQLException {
		String otp = generateOtp();
		patient.setOtpString(otp);
		patient.setStatus("PENDING");
		System.out.println(patient);
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(patient);
		transaction.commit();		
		return "ValidateOtp.jsp?faces-redirect=true";
	}
	
	public PatientMaster searchPatientByUsername(String userName) {
		SessionFactory sf = SessionHelper.getConnection();
		Session session =sf.openSession();
		Criteria cr = session.createCriteria(PatientMaster.class);
		cr.add(Restrictions.eq("username", userName));
		PatientMaster patient = (PatientMaster)cr.uniqueResult();
		return patient;
	}

}
