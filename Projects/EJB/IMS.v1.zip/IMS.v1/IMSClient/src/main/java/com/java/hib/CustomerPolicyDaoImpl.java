package com.java.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class CustomerPolicyDaoImpl implements CustomerPolicyDAO{
	SessionFactory sf;
	Session session;
	
	
}
