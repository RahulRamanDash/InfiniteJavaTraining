package com.java.hib;

public class CustomerAuthorizationDaoImpl implements CustomerAuthorizationDAO{

}
