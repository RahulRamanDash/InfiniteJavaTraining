package com.java.hib;

public interface CustomerAuthorizationDAO {

}
