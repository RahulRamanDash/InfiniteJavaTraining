package com.java.hib;

public interface CustomerPolicyDAO {
	String takePolicy();
}
