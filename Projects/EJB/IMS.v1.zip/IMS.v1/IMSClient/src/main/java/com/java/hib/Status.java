package com.java.hib;

public enum Status {
	Active, Inactive
}
