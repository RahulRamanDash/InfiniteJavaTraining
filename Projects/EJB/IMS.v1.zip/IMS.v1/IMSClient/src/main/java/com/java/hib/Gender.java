package com.java.hib;

public enum Gender {
	Male, Female
}
