package com.java.hib;

public enum PayMode {
	MONTHLY, QUARTERLY, HALFYEARLY, YEARLY
}
