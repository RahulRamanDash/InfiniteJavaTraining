package com.java.hib;

public interface InsuranceDAO {
	
	
}
