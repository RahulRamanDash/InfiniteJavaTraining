package com.java.ejb;

import java.sql.SQLException;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class RoomAllocationBean
 */
@Stateless
@LocalBean
public class RoomAllocationBean implements RoomAllocationBeanRemote {
	
static RoomAllocationDAO roomDao;
	
	static {
		roomDao = new RoomAllocationDaoImpl();
	}
    /**
     * Default constructor. 
     */
    public RoomAllocationBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<String> showRoomType() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return roomDao.showRoomTypeDao();
	}

}
