package com.java.ejb;

import java.sql.SQLException;

public interface PatientMasterDAO {
	String getpatientIdDao();
	String addPatient(PatientMaster patient) throws ClassNotFoundException, SQLException;
}
