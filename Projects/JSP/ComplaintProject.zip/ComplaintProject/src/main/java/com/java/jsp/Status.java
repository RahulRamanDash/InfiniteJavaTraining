package com.java.jsp;

public enum Status {
		
	PENDING,INPROGRESS,RESOLVED,CLOSED,REJECTED;
}
